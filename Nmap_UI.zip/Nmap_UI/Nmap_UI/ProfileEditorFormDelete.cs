﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

// cagri

namespace Nmap_UI
{
    public partial class ProfileEditorFormDelete : Form
    {
        public string ProfileNameValue { get; private set; }
        public string ProfileDescriptionValue { get; private set; }
        public string ProfileCommandValue { get; private set; }
        public bool IsDeleted { get; private set; }

        public ProfileEditorFormDelete(string name, string desc, string cmd)
        {
            InitializeComponent();

            profileCmd_textBox.Text = cmd;
            profileName_textBox.Text = name;
            profileDesc_textBox.Text = desc;

            profileCmd_textBox.ReadOnly = false;
            profileName_textBox.ReadOnly = false;
            profileDesc_textBox.ReadOnly = false;

            profileSave_button.Click += ProfileSave_button_Click;
            profileCancel_button.Click += (s, e) => { DialogResult = DialogResult.Cancel; Close(); };
            profileDelete_button.Click += ProfileDelete_button_Click;
        }

        private void ProfileEditorFormDelete_Load(object sender, EventArgs e)
        {
            help_richTextBox.SelectionFont = new Font("Segoe UI", 12, FontStyle.Bold);
            help_richTextBox.AppendText("Help\n\n");

            help_richTextBox.SelectionFont = new Font("Segoe UI", 10, FontStyle.Regular);
            help_richTextBox.SelectionColor = Color.Black;
            help_richTextBox.AppendText("Profile name:\n");

            help_richTextBox.SelectionFont = new Font("Segoe UI", 8, FontStyle.Regular);
            help_richTextBox.SelectionColor = Color.Black;
            help_richTextBox.AppendText("This is how the profile will be identified in the drop-down combo box " +
                "in the scan tab.\r\n\n");

            help_richTextBox.SelectionFont = new Font("Segoe UI", 10, FontStyle.Regular);
            help_richTextBox.SelectionColor = Color.Black;
            help_richTextBox.AppendText("Description:\n");

            help_richTextBox.SelectionFont = new Font("Segoe UI", 8, FontStyle.Regular);
            help_richTextBox.SelectionColor = Color.Black;
            help_richTextBox.AppendText("The description is a full description of what the scan does, which may be long.");
        }

        private void ProfileSave_button_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(profileName_textBox.Text))
            {
                MessageBox.Show("Please enter a profile name.", "Validation",
                                 MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            ProfileNameValue = profileName_textBox.Text.Trim();
            ProfileDescriptionValue = profileDesc_textBox.Text.Trim();
            ProfileCommandValue = profileCmd_textBox.Text.Trim();
            IsDeleted = false;
            DialogResult = DialogResult.OK;
            Close();
        }

        private void ProfileDelete_button_Click(object sender, EventArgs e)
        {
            var res = MessageBox.Show(
                $"Are you sure you want to delete profile “{profileName_textBox.Text}”?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == DialogResult.Yes)
            {
                IsDeleted = true;
                DialogResult = DialogResult.OK;
                Close();
            }
        }
    }
}
