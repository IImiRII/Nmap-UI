﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Printing;  // print islemi icin
using System.Linq; // .Any() için ekleyin
using System.Text.RegularExpressions;
//SQLite
using System.Data.SQLite;
// Save Open
using System.IO;

namespace Nmap_UI
{
    public partial class Form1 : Form
    {
        // o anda calisan Nmap process
        private Process currentProcess = null;

        // print islemi icin
        private PrintDocument printDocument = new PrintDocument();

        // Scans kismi icin veri yapisi
        private BindingList<ScanEntry> scanList = new BindingList<ScanEntry>();

        // SQLite icin
        private SQLiteConnection _db;


        private bool _wasCancelled = false;
        public class ScanEntry
        {
            public string Status { get; set; }
            public string Command { get; set; }
        }

        // kullanici kendi profilini eklemek icin yapilan veri yapiları
        private Dictionary<string, string> customProfiles = new Dictionary<string, string>();
        private Dictionary<string, string> customDescriptions = new Dictionary<string, string>();

        private readonly Dictionary<string, string> _sessionCache = new Dictionary<string, string>();

        public Form1()
        {
            InitializeComponent();

            //
            this.Load += Form1_Load;

            target_textBox.TextChanged += target_textBox_TextChanged;
            profile_comboBox.SelectedIndexChanged += profile_comboBox_SelectedIndexChanged;
            scan_button.Click += scan_button_Click;
            cancel_button.Click += cancel_button_Click;

            // Profile sekmesindeki butonlar
            newProfileToolStripMenuItem.Click += NewProfileToolStripMenuItem_Click;
            editProfileToolStripMenuItem.Click += EditProfileToolStripMenuItem_Click;

            // About
            aboutToolStripMenuItem.Click += AboutToolStripMenuItem_Click;

            newWindowToolStripMenuItem.Click += NewWindowToolStripMenuItem_Click;
            printToolStripMenuItem.Click += PrintToolStripMenuItem_Click;
            quitToolStripMenuItem.Click += QuitToolStripMenuItem_Click;


            // PrintDocument sayfa basmayı dinlesin
            printDocument.PrintPage += PrintDocument_PrintPage;

            // Help
            helpToolStripMenuItem1.Click += HelpToolStripMenuItem1_Click;

            // Report a Bug
            reportABugToolStripMenuItem.Click += ReportABugToolStripMenuItem_Click;

            // Gecmis taramalari gormek icin
            historyComboBox.SelectedIndexChanged += HistoryComboBox_SelectedIndexChanged;


            //profile_comboBox.SelectedIndexChanged += profile_comboBox_SelectedIndexChanged;
            //target_textBox.TextChanged += target_textBox_TextChanged;

            //scan_button.Click += scan_button_Click;
            //cancel_button.Click += cancel_button_Click;
            btnRemoveScan.Click += btnRemoveScan_Click;
            btnCancelScan.Click += btnCancelScan_Click;

            saveScanToolStripMenuItem.Click += SaveScanToolStripMenuItem_Click;
            openScanToolStripMenuItem.Click += OpenScanToolStripMenuItem_Click;

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // 0) History ComboBox'ı salt okunur ve boş başlasın
            historyComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            historyComboBox.Items.Clear();

            _sessionCache.Clear();
            output_richbox.Clear();

            os_host_flowLayoutPanel.FlowDirection = FlowDirection.TopDown;
            os_host_flowLayoutPanel.WrapContents = false;
            os_host_flowLayoutPanel.AutoScroll = true;

            // 1) Veritabanı dosyamızın yolu ve bağlantı
            string dbFile = Path.Combine(Application.StartupPath, "scans.db");
            bool firstTime = !File.Exists(dbFile);

            _db = new SQLiteConnection($"Data Source={dbFile};Version=3;");
            _db.Open();

            // 2) Scans tablosunu oluştur (varsa atla)
            using (var cmd = new SQLiteCommand(@"
                                                CREATE TABLE IF NOT EXISTS Scans (
                                                    Command TEXT PRIMARY KEY,
                                                    Output  TEXT
                                                );", _db))
            {
                cmd.ExecuteNonQuery();
            }

            // 3) Profiles tablosunu oluştur
            using (var cmd = new SQLiteCommand(@"
                                                CREATE TABLE IF NOT EXISTS Profiles (
                                                    Name        TEXT PRIMARY KEY,
                                                    Command     TEXT NOT NULL,
                                                    Description TEXT
                                                );", _db))
            {
                cmd.ExecuteNonQuery();
            }

            // 4) profile_comboBox'u baştan temizle
            profile_comboBox.Items.Clear();

            // 4a) Kodla tanımlı varsayılan profiller
            var defaults = new[]
            {
                "Intense scan",
                "Intense scan plus UDP",
                "Intense scan, all TCP ports",
                "Intense scan, no ping",
                "Ping scan",
                "Quick scan",
                "Quick scan plus",
                "Quick traceroute",
                "Regular scan",
                "Slow comprehensive scan",
                "Manual scan"
            };
            foreach (var d in defaults)
                profile_comboBox.Items.Add(d);

            // 4b) Veritabanındaki custom profilleri ekle (tekrarı engelle)
            using (var cmd = new SQLiteCommand(
                "SELECT Name, Command, Description FROM Profiles", _db))
            using (var reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    string name = reader.GetString(0);
                    string command = reader.GetString(1);
                    string desc = reader.IsDBNull(2) ? "" : reader.GetString(2);

                    customProfiles[name] = command;
                    customDescriptions[name] = desc;

                    if (!profile_comboBox.Items.Contains(name))
                        profile_comboBox.Items.Add(name);
                }
            }

            // 5) Başlangıç seçimi
            if (profile_comboBox.Items.Count > 0)
                profile_comboBox.SelectedIndex = 0;

            // 6) History'i DB'den yükle (combobox'ı temizler ve tek tek ekler)
            //LoadHistoryFromDatabase();

            // 7) Temel UI ayarları
            this.Text = "Nmap";
            target_textBox.Text = " ";
            command_textBox.ReadOnly = true; // otomatik profil modu için
            //

            // 8) ScansDataGridView kolonlarını kur
            scans_DataGridView.AutoGenerateColumns = false;
            scans_DataGridView.Columns.Clear();
            scans_DataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Status",
                DataPropertyName = "Status",
                HeaderText = "Status",
                ReadOnly = true
            });
            scans_DataGridView.Columns.Add(new DataGridViewTextBoxColumn
            {
                Name = "Command",
                DataPropertyName = "Command",
                HeaderText = "Command",
                ReadOnly = true,
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });
            scans_DataGridView.DataSource = scanList;

            // 9) Scan/Cancel butonları
            
        }

        private void OpenScanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var dlg = new OpenFileDialog())
            {
                dlg.Filter = "Metin Dosyası|*.txt";
                if (dlg.ShowDialog(this) != DialogResult.OK)
                    return;

                // Dosyayı satır satır oku
                var lines = File.ReadAllLines(dlg.FileName, Encoding.UTF8);

                // 1) İlk satır "Command: ..." ise komutu al ve Command kutusuna yaz
                string cmdLine = "";
                if (lines.Length > 0 && lines[0].StartsWith("Command: "))
                {
                    cmdLine = lines[0].Substring("Command: ".Length);
                    command_textBox.Text = cmdLine;

                    // Komuttaki son token'ın IP olduğu varsayımıyla target'ı da ayarla:
                    var parts = cmdLine.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    if (parts.Length >= 2)
                    {
                        string ip = parts[parts.Length - 1];
                        target_textBox.Text = ip;
                    }
                }

                // 2) Başlık ve boş satırı atlayarak gerçek çıktıyı al
                int idx = 0;
                while (idx < lines.Length && !string.IsNullOrWhiteSpace(lines[idx]))
                    idx++;
                // boş satırı atlarken idx++ yap
                if (idx < lines.Length && string.IsNullOrWhiteSpace(lines[idx]))
                    idx++;

                var output = string.Join(Environment.NewLine, lines.Skip(idx));
                output_richbox.Text = output;


                // 3) Hosts panelini temizle ve yeniden doldur
                os_host_flowLayoutPanel.Controls.Clear();

                // IP artık target_textBox'ta
                string ipHost = target_textBox.Text.Trim();
                // OS baş harfini çıktıdan tespit et
                char osInitial = GetOsInitialFromOutput(output);

                

                if (!string.IsNullOrEmpty(ipHost))
                    AddOsHostLink(osInitial, ipHost);

                // 4) Diğer sekmeleri de güncelle
                PopulatePortsGrid(ipHost, output);
               
                PopulateHostDetails(ipHost, output);


                
                
            }
        }
        private void SaveScanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(output_richbox.Text))
            {
                MessageBox.Show("Kaydedilecek bir tarama çıktısı yok.", "Uyarı",
                                MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "Metin Dosyası|*.txt";
                dlg.DefaultExt = "txt";
                dlg.FileName = "scan.txt";

                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    using (var w = new StreamWriter(dlg.FileName, false, Encoding.UTF8))
                    {
                        // İsteğe bağlı başlıklar
                        w.WriteLine($"Command: {command_textBox.Text}");
                        w.WriteLine($"Date:    {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
                        w.WriteLine();  // boş satır
                        w.Write(output_richbox.Text);
                    }
                    MessageBox.Show("Tarama kaydedildi.", "Bilgi",
                                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
        private void LoadHistoryFromDatabase()
        {
            // 1) Önceki listeyi temizle
            historyComboBox.Items.Clear();

            // 2) SQL ve komutu yaratırken bağlantıyı (_db) veriyoruz
            string sql = "SELECT DISTINCT Command FROM Scans ORDER BY ROWID";
            using (var cmd = new SQLiteCommand(sql, _db))
            {
                // 3) reader için de klasik using
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        historyComboBox.Items.Add(reader.GetString(0));
                    }
                }
            }

            // 4) Eğer varsa son elemanı seçili yap
            if (historyComboBox.Items.Count > 0)
                historyComboBox.SelectedIndex = historyComboBox.Items.Count - 1;
        }

        // Alttaki iki metot SQLite icin
        /// <summary>
        /// Veritabanına (Command, Output) çiftini ekler veya günceller.
        /// </summary>
        private void SaveScanToDatabase(string commandText, string outputText)
        {
            // INSERT OR REPLACE INTO Scans(Command, Output) VALUES(@cmd,@out)
            using (var cmd = new SQLiteCommand("INSERT OR REPLACE INTO Scans (Command, Output) VALUES (@cmd, @out)", _db))
            {
                cmd.Parameters.AddWithValue("@cmd", commandText);
                cmd.Parameters.AddWithValue("@out", outputText);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Veritabanından verilen komuta karşılık gelen Output değerini döner. Bulamazsa boş string.
        /// </summary>
        private string LoadScanOutput(string commandText)
        {
            using (var cmd = new SQLiteCommand("SELECT Output FROM Scans WHERE Command = @cmd", _db))
            {
                cmd.Parameters.AddWithValue("@cmd", commandText);
                object result = cmd.ExecuteScalar();
                if (result != null && result != DBNull.Value)
                    return result.ToString();
                return string.Empty;
            }
        }

        // Alttaki 3 metot print metodu icin
        private void NewWindowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // Aynı formun yeni bir örneğini aç
            var win = new Form1();
            win.Show();
        }

        private void PrintToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var dlg = new PrintDialog())
            {
                dlg.Document = printDocument;
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    printDocument.Print();
                }
            }
        }

        // Quit
        private void QuitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // History
        private void HistoryComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedCmd = historyComboBox.SelectedItem as string;
            if (string.IsNullOrEmpty(selectedCmd))
                return;

            // 1) Command kutusuna geri aktar
            command_textBox.Text = selectedCmd;

            // 2) Cache’de varsa ordaki çıktıyı al, yoksa DB’den oku
            if (_sessionCache.TryGetValue(selectedCmd, out var cachedOutput))
            {
                output_richbox.Text = cachedOutput;
            }
            else
            {
                output_richbox.Text = LoadScanOutput(selectedCmd);
            }
        }

        // Report a Bug
        private void ReportABugToolStripMenuItem_Click(object sender, EventArgs e)
        {
            var win = new ReportBug();
            win.Show();
        }

        // Help
        private void HelpToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            var win = new HelpForm();
            win.Show();
        }

        // Burada sayfa başına metni basıyoruz.
        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            // Yazdırılacak metin (richTextBox'taki tüm çıktı)
            string text = output_richbox.Text;
            // Basit bir mono-space font seçelim
            using (Font f = new Font("Consolas", 10))
            {
                // Metni margin alanına yazdır
                e.Graphics.DrawString(
                    text,
                    f,
                    Brushes.Black,
                    e.MarginBounds.Left,
                    e.MarginBounds.Top
                );
            }
            // Tek sayfada sığmayacaksa e.HasMorePages = true; ekleyebilirsiniz.
        }

        // Alttaki bir metot About kismi icin
        private void AboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var about = new AboutForm())
            {
                about.ShowDialog(this);
            }
        }

        // Alttaki iki metot Profile sekmesi icin
        private void NewProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            using (var editor = new ProfileEditorForm())
            {
                if (editor.ShowDialog(this) == DialogResult.OK)
                {
                    var name = editor.ProfileNameValue;
                    var cmd = editor.ProfileCommandValue;
                    var desc = editor.ProfileDescriptionValue;

                    // Sözlük ve UI
                    profile_comboBox.Items.Add(name);
                    customProfiles[name] = cmd;
                    customDescriptions[name] = desc;
                    profile_comboBox.SelectedItem = name;

                    // **Veritabanına kaydet**
                    SaveProfileToDatabase(name, cmd, desc);
                }
            }
        }

        private void EditProfileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!(profile_comboBox.SelectedItem is string oldName)) return;
            customProfiles.TryGetValue(oldName, out var oldCmd);
            customDescriptions.TryGetValue(oldName, out var oldDesc);

            using (var editor = new ProfileEditorFormDelete(oldName, oldDesc, oldCmd))
            {
                if (editor.ShowDialog(this) != DialogResult.OK)
                    return;

                if (editor.IsDeleted)
                {
                    // 1) Sözlük ve UI’dan sil
                    customProfiles.Remove(oldName);
                    customDescriptions.Remove(oldName);
                    profile_comboBox.Items.Remove(oldName);

                    // 2) Veritabanından sil
                    RemoveProfileFromDatabase(oldName);
                }
                else
                {
                    string newName = editor.ProfileNameValue;
                    string newCmd = editor.ProfileCommandValue;
                    string newDesc = editor.ProfileDescriptionValue;

                    // İsim değiştiyse
                    if (newName != oldName)
                    {
                        int idx = profile_comboBox.Items.IndexOf(oldName);
                        profile_comboBox.Items[idx] = newName;
                        customProfiles.Remove(oldName);
                        customDescriptions.Remove(oldName);

                        // Veritabanında eski adı sil, yenisini ekle
                        RemoveProfileFromDatabase(oldName);
                    }

                    // Sözlük ve UI
                    customProfiles[newName] = newCmd;
                    customDescriptions[newName] = newDesc;
                    profile_comboBox.SelectedItem = newName;

                    // **Veritabanına kaydet** (insert or replace)
                    SaveProfileToDatabase(newName, newCmd, newDesc);
                }
            }
        }


        // Nmap komutunu yeniler
        private void target_textBox_TextChanged(object sender, EventArgs e)
        {
            UpdateCommandDisplay();
        }
        // Nmap komutunu yeniler
        private void profile_comboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool manual = profile_comboBox.Text == "Manual scan";

            // Manual moddaysa kullanıcı müdahalesine izin verelim,
            // aksi halde otomatik doldursun ve salt-okunur yapsın:
            command_textBox.ReadOnly = !manual;

            // Seçim değişince komutu güncelle
            UpdateCommandDisplay();
        }

        private void UpdateCommandDisplay()
        {
            if (profile_comboBox.Text == "Manual scan")
            {
                // 'nmap ' önekiyle target'ı command'a yansıt
                command_textBox.Text = $"nmap {target_textBox.Text}";
                return;
            }

            // Önce custom Profiles sözlüğünde arayalım
            string profile = profile_comboBox.Text;
            string cmd = customProfiles.TryGetValue(profile, out var custom)
                           ? custom
                           : GetProfileCommand(profile);

            // Ardından target ekle
            command_textBox.Text = $"nmap {cmd} {target_textBox.Text}";

        }


        // 2) Seçileni kaldırmak
        private void btnRemoveScan_Click(object sender, EventArgs e)
        {
            if (scans_DataGridView.CurrentRow == null) return;
            var entry = (ScanEntry)scans_DataGridView.CurrentRow.DataBoundItem;
            scanList.Remove(entry);
        }

        // 3) Cancel Scan: 
        //    - Eğer o anda bir process çalışıyorsa durdursun.
        //    - İstersen, seçili satırın Status’ünü "Canceled" yapsın.
        private void btnCancelScan_Click(object sender, EventArgs e)
        {
            if (currentProcess != null && !currentProcess.HasExited)
            {
                currentProcess.Kill();
                currentProcess = null;
            }

            if (scans_DataGridView.CurrentRow != null)
            {
                var entry = (ScanEntry)scans_DataGridView.CurrentRow.DataBoundItem;
                entry.Status = "Canceled";
                scans_DataGridView.Refresh();
            }
        }

        private string GetProfileCommand(string profile)
        {
            // Önce custom profil var mı bak
            if (customProfiles.TryGetValue(profile, out var customCmd))
                return customCmd;

            // Profil secimine gore nmap komutu.
            switch (profile)
            {
                case "Intense scan":
                    return "-T4 -A -v";
                case "Intense scan plus UDP":
                    return "-sS -sU -T4 -A -v";
                case "Intense scan, all TCP ports":
                    return "-p 1-65535 -T4 -A -v";
                case "Intense scan, no ping":
                    return "-T4 -A -v -Pn";
                case "Ping scan":
                    return "-sn";
                case "Quick scan":
                    return "-T4 -F";
                case "Quick scan plus":
                    return "-sV -T4 -O -F --version-light";
                case "Quick traceroute":
                    return "-sn --traceroute";
                case "Regular scan":
                    return " ";
                case "Slow comprehensive scan":
                    return "nmap -sS -sU -T4 -A -v -PE -PP -PS80,443 -PA3389 -PU40125 -PY -g 53 --script \"default or (discovery and safe)\"";
                case "Manual scan":
                    return "";
                default:
                    return "";
            }
        }

        private string GetProfileDescription(string profile)
        {
            switch (profile)
            {
                case "Intense scan":
                    return "Versiyon tespiti, OS tespiti, script taraması ve traceroute içeren yoğun tarama.";
                case "Intense scan plus UDP":
                    return "TCP yoğun taramaya UDP portlarını da ekler.";
                case "Intense scan, all TCP ports":
                    return "Tüm 1-65535 TCP portlarını versiyon bilgisiyle birlikte tarar.";
                case "Intense scan, no ping":
                    return "Yoğun tarama fakat host keşfi için ping atmaz (-Pn).";
                case "Ping scan":
                    return "Sadece host up/down bilgisini alır, port taramaz.";
                case "Quick scan":
                    return "İlk 100 porta hızlı tarama yapar (-F).";
                case "Quick scan plus":
                    return "Hızlı tarama + servis versiyonu ve OS tespiti.";
                case "Quick traceroute":
                    return "Ping scan + traceroute işlemi.";
                case "Regular scan":
                    return "Varsayılan 1000 porta tarama.";
                case "Slow comprehensive scan":
                    return "Uzun süreli, geniş kapsamlı script ve ping içeren tarama.";
                case "Manual scan":
                    return "Komut satırına tamamen kendi argümanlarınızı girin.";
                default:
                    return "";
            }
        }

        // Nmap komutunu cmd'den calistir ve ciktiyi goster.
        // async cunku anlik olarak ciktinin degismesini istiyoruz.
        private async void RunNmapScan()
        {
            scan_button.Enabled = false;
            cancel_button.Enabled = true;

            if (profile_comboBox.Text != "Manual scan")
                UpdateCommandDisplay();

            string command = command_textBox.Text.Trim();
            string collectedOutput = "";

            try
            {
                // 1) Komutu parçala: exe + argümanlar
                var tokens = command.Split(new[] { ' ' }, 2);
                var exe = tokens[0];
                var args = tokens.Length > 1 ? tokens[1] : "";

                var startInfo = new ProcessStartInfo
                {
                    FileName = exe,
                    Arguments = args,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                };

                var process = new Process { StartInfo = startInfo };
                currentProcess = process;

                process.OutputDataReceived += (s, e) =>
                {
                    if (!string.IsNullOrEmpty(e.Data))
                    {
                        collectedOutput += e.Data + "\n";
                        AppendOutput(e.Data + "\n");
                    }
                };
                process.ErrorDataReceived += (s, e) =>
                {
                    if (!string.IsNullOrEmpty(e.Data))
                    {
                        collectedOutput += e.Data + "\n";
                        AppendOutput(e.Data + "\n");
                    }
                };

                output_richbox.Clear();
                process.Start();
                process.BeginOutputReadLine();
                process.BeginErrorReadLine();

                // nmap süreci bitene kadar bekle (UI donmasın)
                await Task.Run(() => process.WaitForExit());

                // İptal edildi mi?
                if (_wasCancelled)
                {
                    _wasCancelled = false;    // bir kerelik iptal
                    scan_button.Enabled = true;
                    cancel_button.Enabled = false;
                    currentProcess = null;
                    return;                   // DB’ye yazma / Done güncelleme yapmadan çık
                }

                // 2) Tarama tamamlandı — artık process’i “serbest bırak”
                currentProcess = null;

                // 3) UI güncellemeleri
                string ip = target_textBox.Text.Trim();
                char osInitial = GetOsInitialFromOutput(collectedOutput);
                AddOsHostLink(osInitial, ip);
                PopulatePortsGrid(ip, collectedOutput);
                PopulateHostDetails(ip, collectedOutput);

                var last = scanList.LastOrDefault(s => s.Command == command);
                if (last != null)
                {
                    last.Status = "Done";
                    scans_DataGridView.Refresh();
                }

                // 4) Oturum önbelleğine yaz
                _sessionCache[command] = collectedOutput;

                // 5) Kalıcı kayda da DB'ye yaz
                SaveScanToDatabase(command, collectedOutput);

                scan_button.Enabled = true;
                cancel_button.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error running Nmap: {ex.Message}");
                scan_button.Enabled = true;
                cancel_button.Enabled = false;
            }
        }


        // Alttaki iki metot profil eklenince kalmasini saglar.
        /// <summary>Profil tablosuna ekler veya günceller.</summary>
        private void SaveProfileToDatabase(string name, string command, string description)
        {
            using (var cmd = new SQLiteCommand(@"
        INSERT OR REPLACE INTO Profiles (Name, Command, Description)
        VALUES (@name, @cmd, @desc)
    ", _db))
            {
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@cmd", command);
                cmd.Parameters.AddWithValue("@desc", description);
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>Profil tablosundan siler.</summary>
        private void RemoveProfileFromDatabase(string name)
        {
            using (var cmd = new SQLiteCommand("DELETE FROM Profiles WHERE Name = @name", _db))
            {
                cmd.Parameters.AddWithValue("@name", name);
                cmd.ExecuteNonQuery();
            }
        }

        private void cancel_button_Click(object sender, EventArgs e)
        {
            if (currentProcess != null && !currentProcess.HasExited)
            {
                _wasCancelled = true;
                currentProcess.Kill();
            }

            try
            {
                if (currentProcess != null && !currentProcess.HasExited)
                {
                    currentProcess.Kill();
                    currentProcess.WaitForExit();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Cancel error!: {ex.Message}");
            }
            finally
            {
                currentProcess = null;
                output_richbox.Clear();
                profile_comboBox.SelectedIndex = 0;
            }
        }

        private void PopulatePortsGrid(string ip, string collectedOutput)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string, string>(PopulatePortsGrid), ip, collectedOutput);
                return;
            }

            // 1) Önceki satırları temizleyelim:
            portsDataGridView.Rows.Clear();

            // 2) Her satırı ayrı işleyelim
            var lines = collectedOutput
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            // Regex: port/protocol  state  service  [version...]
            var regex = new Regex(@"^(\d+)\/(tcp|udp)\s+(\S+)\s+(\S+)(?:\s+(.+))?$",
                                  RegexOptions.IgnoreCase);

            foreach (var line in lines)
            {
                var m = regex.Match(line);
                if (!m.Success)
                    continue;

                string port = m.Groups[1].Value;
                string protocol = m.Groups[2].Value;
                string state = m.Groups[3].Value;
                string service = m.Groups[4].Value;
                string version = m.Groups[5].Success ? m.Groups[5].Value : "";

                // O: open, C: başka her durum
                string yk = state.Equals("open", StringComparison.OrdinalIgnoreCase)
                              ? "O" : "C";

                portsDataGridView.Rows.Add(
                    ip,      // Host
                    yk,      // Y/K
                    port,    // Port
                    protocol,// Protocol
                    state,   // State
                    service, // Service
                    version  // Version
                );
            }


            string cmdLine = command_textBox.Text.Trim();
            if (!string.IsNullOrEmpty(cmdLine))
            {
                // Burada “Loaded” durumunu kullanıyoruz, dilerseniz “Done” da yazabilirsiniz
                scanList.Add(new ScanEntry
                {
                    Status = "Done",
                    Command = cmdLine
                });
            }
        }

        private void PopulateHostDetails(string ip, string output)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string, string>(PopulateHostDetails), ip, output);
                return;
            }

            // Temizle
            hostDetails_treeView.Nodes.Clear();

            // Kök düğüm: IP
            var root = new TreeNode(ip);

            // 1) Host Status
            var statusNode = new TreeNode("Host Status");

            // State
            string state = output.Contains("Host is up") ? "up" : "down";
            statusNode.Nodes.Add($"State: {state}");

            // Open, Filtered, Closed port sayıları
            var openRegex = new Regex(@"(\d+)\/(?:tcp|udp)\s+open", RegexOptions.IgnoreCase);
            var filteredRegex = new Regex(@"(\d+)\/(?:tcp|udp)\s+filtered", RegexOptions.IgnoreCase);
            var closedRegex = new Regex(@"Not shown:\s*(\d+)\s*closed ports", RegexOptions.IgnoreCase);

            int openCount = openRegex.Matches(output).Count;
            int filteredCount = filteredRegex.Matches(output).Count;
            int closedCount = 0;
            var mClosed = closedRegex.Match(output);
            if (mClosed.Success) closedCount = int.Parse(mClosed.Groups[1].Value);

            statusNode.Nodes.Add($"Open ports: {openCount}");
            statusNode.Nodes.Add($"Filtered ports: {filteredCount}");
            statusNode.Nodes.Add($"Closed ports: {closedCount}");
            statusNode.Nodes.Add($"Scanned ports: {openCount + filteredCount + closedCount}");

            // Up time & Last boot (metin çıktıda yoksa “Not available”)
            statusNode.Nodes.Add("Up time: Not available");
            statusNode.Nodes.Add("Last boot: Not available");

            root.Nodes.Add(statusNode);

            // 2) Addresses
            var addrNode = new TreeNode("Addresses");
            addrNode.Nodes.Add($"IPv4: {ip}");
            addrNode.Nodes.Add("IPv6: Not available");

            // MAC Address
            var macRegex = new Regex(@"MAC Address:\s*([0-9A-F:]+)", RegexOptions.IgnoreCase);
            var mMac = macRegex.Match(output);
            addrNode.Nodes.Add($"MAC: {(mMac.Success ? mMac.Groups[1].Value : "Not available")}");

            root.Nodes.Add(addrNode);

            // (İsteğe bağlı) Comments vb. ekleyebilirsiniz

            // Ağaca ekle ve hepsini aç
            hostDetails_treeView.Nodes.Add(root);
            hostDetails_treeView.ExpandAll();
        }

        private void UpdateOutput(string output)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<string>(UpdateOutput), new object[] { output });
                return;
            }
            output_richbox.Text = output;
        }

        private void AppendOutput(string text)
        {
            if (output_richbox.InvokeRequired)
            {
                output_richbox.Invoke(new Action(() => output_richbox.AppendText(text)));
            }
            else
            {
                output_richbox.AppendText(text);
            }
        }

        // outputta gerekli isletim sistemi stringini arar.
        private char GetOsInitialFromOutput(string nmapOutput)
        {
            if (nmapOutput.IndexOf("Windows", StringComparison.InvariantCultureIgnoreCase) >= 0)
                return 'W';
            if (nmapOutput.IndexOf("Linux", StringComparison.InvariantCultureIgnoreCase) >= 0)
                return 'L';
            // Başka OS’ler icin ekleme
            return '?';
        }

        // FlowLayoutPanel icine bir LinkLabel daha ekler
        private void AddOsHostLink(char osInitial, string ip)
        {
            if (InvokeRequired)
            {
                this.Invoke(new Action<char, string>(AddOsHostLink), osInitial, ip);
                return;
            }

            string labelText = $"{osInitial}    {ip}";

            // aynisi varsa ekleme
            bool exists = os_host_flowLayoutPanel.Controls
                .OfType<LinkLabel>()
                .Any(ll => ll.Text == labelText);
            if (exists)
                return;

            // yeni linkLayer olursur ve ekle
            var link = new LinkLabel
            {
                Text = labelText,
                AutoSize = true,
                Margin = new Padding(3),
            };
            link.LinkClicked += (s, e) =>
            {
                MessageBox.Show($"Host has been clicked: {ip}", "Host has been selected",
                                MessageBoxButtons.OK, MessageBoxIcon.Information);
            };

            os_host_flowLayoutPanel.Controls.Add(link);
        }

        private void scan_button_Click(object sender, EventArgs e)
        {
            string cmd = command_textBox.Text.Trim();
            if (!string.IsNullOrEmpty(cmd))
            {
                // Scan tablosuna ekleme
                scanList.Add(new ScanEntry { Status = "Unsaved", Command = cmd });

                // History ComboBox'a ekle (aynı komutu iki kere eklememek için kontrol edebilirsiniz)
                if (!historyComboBox.Items.Contains(cmd))
                {
                    historyComboBox.Items.Add(cmd);
                }
                // En alta inelim
                historyComboBox.SelectedIndex = historyComboBox.Items.Count - 1;
            }

            RunNmapScan();
        }

       
    }
}
